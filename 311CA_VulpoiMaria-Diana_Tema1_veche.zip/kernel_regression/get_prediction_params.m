function [a] = get_prediction_params(K, y, lambda)

    % Calculam dimensiunea matricei K
    [n, ~] = size(K);

    % Adaugam termenul de regularizare pe diagonala principala a matricei K
    regularization = K + lambda * eye(n);

    %L matrice inferior triunghiulara
    L = cholesky(regularization);

    % Rezolvam primul sistem triangular: L * z = y
    z = L \ y;

    % Rezolvam al doilea sistem triangular: L' * a = z
    a = L' \ z;
endfunction
