function retval = linear_kernel (x, y, other)
  retval = x * y';
endfunction
