function probs = sample_next_word(text, words_idx, k_secv_idx, k, stoch)
    last_k_seq = text(end-k+1:end);
    
    if isKey(k_secv_idx, last_k_seq)
        k_secv_index = k_secv_idx(last_k_seq);
        probs = stoch(k_secv_index, :);
    endif
endfunction
