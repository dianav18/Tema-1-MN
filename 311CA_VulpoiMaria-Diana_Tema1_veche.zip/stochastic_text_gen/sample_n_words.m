function retval = sample_n_words(text, widx, kscvidx, k, stoch, word_set, n)
    retval = text;
    for i = 1:n
        k_seq = text(end - k + 1:end);
        if isfield(kscvidx, k_seq)
            next_word_candidates = kscvidx.(k_seq);
        else
            next_word_candidates = stoch;
        endif
        next_word_idx = randsample(next_word_candidates, 1);
        next_word = widx{next_word_idx};
        retval = [retval ' ' next_word];
        text = [text ' ' next_word];
    endfor
endfunction
