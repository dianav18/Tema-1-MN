function retval = word_idx (distinct_wds)
	retval = containers.Map(distinct_wds, 1:length(distinct_wds));
endfunction