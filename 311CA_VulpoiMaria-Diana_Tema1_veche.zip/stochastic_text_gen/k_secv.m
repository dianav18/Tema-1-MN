function B = k_secv(A, k)
    %A - cell array cu cuvintele din text
    %k - numarul de cuvinte din fiecare secventa
    %B - cell array cu secventele de k cuvinte
    B = cell(0,1);
    %numarul de secvente de k cuvinte
    num_of_sequences = length(A) - k;

    for i = 1:num_of_sequences
        %extragem secventa de k cuvinte
        sequence = A(i:i+k-1);
        %concatenam cuvintele din secventa
        concatenatedSequence = strjoin(sequence, ' ');
        B{end+1, 1} = concatenatedSequence;  
    endfor
endfunction
