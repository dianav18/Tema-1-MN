function run_test()
    "task-2";
    fout = fopen("out", "w+");
    load("../../input/task2/load1.mat");
    
    

    [X_train, y_train, X_pred, y_pred] = split_dataset(points, z, 0.65);
    
    [K] = build_kernel(X_train, @gaussian_kernel, 1);
       
    
    [a] = get_prediction_params_iterative(K, y_train, 1);
    
    
    n = size(a, 1);
    
    for i = 1 : n
    	fprintf(fout, "%e\n", a(i));
    endfor
    fclose(fout);
endfunction
