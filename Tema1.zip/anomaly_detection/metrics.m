
function [precision recall F1] = metrics(true_pozitives, false_pozitives, false_negatives)
    % precision = 0;
    % recall = 0;
    % F1 = 0;
endfunction