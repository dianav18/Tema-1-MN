function probability = gaussian_distribution(X, mean_value, variance)
    % probability = 0;
endfunction