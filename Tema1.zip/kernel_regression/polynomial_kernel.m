function retval = polynomial_kernel (x, y, d)
  # TO DO: implement polynomial kernel function
  retval = (x * y' + 1) ^ d;
endfunction
