function retval = linear_kernel (x, y, other)
  # TO DO: implement linear kernel function
  # Ignorati parametrul other pentru aceasta functie
  retval = x * y';
endfunction
