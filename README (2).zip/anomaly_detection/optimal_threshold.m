function [best_epsilon, best_F1, associated_precision, associated_recall] = optimal_threshold(truths, probabilities)
    %initializare variabile
    best_epsilon = 0;
    best_F1 = 0;
    associated_precision = 0;
    associated_recall = 0;
    
    %dimensiunea pasului
    step_size = (max(probabilities) - min(probabilities)) / 1000;

    thresholds = min(probabilities):step_size:max(probabilities);


    %se parcurge fiecare valoare de prag
    for epsilon = thresholds
        %se calculeaza predictiile
        predictions = zeros(size(probabilities));
        for i = 1:length(probabilities)
            %daca probabilitatea este mai mica decat pragul, atunci se considera ca este o anomalie
            if probabilities(i) < epsilon
                predictions(i) = 1;
            else
            %daca probabilitatea este mai mare decat pragul, se considera ca nu este o anomalie
                predictions(i) = 0;
            endif
        endfor
        %calculeaza numarul de fals pozitive si adevarat pozitive
        [false_positives, ~, true_positives] = check_predictions(predictions, truths);

        %calculeaza numarul de fals negative si adevarat pozitive
        [~, false_negatives, true_positives] = check_predictions(predictions, truths);

        %calculeaza metricile
        [precision recall F1] = metrics(true_positives, false_positives, false_negatives);

        %se actualizeaza cel mai bun scor F1
        if F1 > best_F1
            best_epsilon = epsilon;
            best_F1 = F1;
            associated_precision = precision;
            associated_recall = recall;
        endif
    endfor
endfunction
